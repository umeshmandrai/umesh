<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Home page</title>
	<link rel="stylesheet" type="text/css" href="css/success.css">
</head>
<body>

    <nav>
    	<label class="logo">Food Restaurant</label>
    </nav>
    <div class="go">
    	<h4 align="center">
    		Checkout</h4>
            <h5>Thank you for your order.............</h5>
   
    	
    </div>
</body>
</html>