<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Food page</title>
	<link rel="stylesheet" type="text/css" href="css/food.css">
</head>
<body>

    <nav>
    	<label class="logo">Food Restaurant</label>
    </nav>
<section class="items">
    <div class="item">
        <img src="image/a.jpg">
        <h2>HUMburger</h2>
        <h4>Price: 100</h4>
        <h4>Total: 1</h4>
        <h4>Cost(INR): 100</h4>
        <button><a href="success.php">+</a></button><button class="button1">-</button>
    </div>
    <div class="item">
        <img src="image/b.jpg">
        <h2>Fries</h2>
        <h4>Price: 100</h4>
        <h4>Total: 1</h4>
        <h4>Cost(INR): 100</h4>
        <button><a href="success.php">+</a></button><button class="button1">-</button>
    </div>
    <div class="item">
        <img src="image/a.jpg">
        <h2>Coke</h2>
        <h4>Price: 100</h4>
        <h4>Total: 1</h4>
        <h4>Cost(INR): 100</h4>
        <button><a href="success.php">+</a></button><button class="button1">-</button>
    </div>
    <div class="item">
        <img src="image/d.jpg">
        <h2>Pepsi</h2>
        <h4>Price: 100</h4>
        <h4>Total: 1</h4>
        <h4>Cost(INR): 100</h4>
        <button><a href="success.php">+</a></button><button class="button1">-</button>
    </div>
    
</section>
</body>
</html>