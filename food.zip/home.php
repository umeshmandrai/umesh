<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Home page</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

    <nav>
    	<label class="logo">Food Restaurant</label>
    </nav>
    <div class="go">
    	<h2 align="center">
    		Welcome to Food's 
    		Kitchen</h2>
    	<center><button><a href="food.php">Go To MENU</a></button>
    	</center>
    </div>
</body>
</html>